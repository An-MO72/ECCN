from eccn import db, app
from sqlalchemy.orm import relationship

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(30), unique=False, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(180), unique=False, nullable=False)
    rating_id = db.Column(db.Integer, db.ForeignKey('ratings.rating_id'), nullable=True)
    ratings = relationship('Ratings', backref='User')
    def __repr__(self):
        return '<User %r>' % self.name
    

class Ratings(db.Model):
    rating_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, unique=False, nullable=False)
    product_id = db.Column(db.Integer, unique=False, nullable=False)
    rating = db.Column(db.Float)


    def __repr__(self):
        return f"<Rating {self.name}>"

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    rating_id = db.Column(db.Integer, db.ForeignKey('ratings.rating_id'), nullable=True)
    description = db.Column(db.Text, nullable=True)
    photo = db.Column(db.String(1000))
    category = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

    ratings = relationship('Ratings', backref='products')
    user = relationship('User', backref='products')


    def __repr__(self):
        return f"<Product {self.name}>"
    

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.String(255), nullable=False)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    timestamp = db.Column(db.DateTime, default=db.func.current_timestamp())

    sender = relationship('User', foreign_keys=[sender_id])
    receiver = relationship('User', foreign_keys=[receiver_id])
    product = relationship('Product', foreign_keys=[product_id])


with app.app_context():
    db.create_all()