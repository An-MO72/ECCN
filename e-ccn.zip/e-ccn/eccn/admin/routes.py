from flask import Flask, render_template, session, request, redirect, url_for, flash, jsonify

from flask_login import login_required, current_user, login_user

from eccn import app, db, bcrypt
from .forms import RegistrationForm, LoginForm
from .models import *
from .colfil import colfil
import os, json
from sqlalchemy import desc, create_engine



@app.before_request
def check_authentication():
    # Check if the user is authenticated
    if 'email' not in session and request.endpoint in ['dash','chat']:
        # Redirect to the login page if not authenticated
        return redirect(url_for('login'))
    
@app.route('/logout')
def logout():
    # Clear the session and log the user out
    session.clear()
    return redirect(url_for('products'))
    

@app.route('/')
def home():
    connected = False
    try:
     if session['name']:
        connected = True
     return render_template('admin/home.html', title="E-CCN", connected=connected, home=True)
    except KeyError:
     return render_template('admin/home.html', title="E-CCN", connected=connected, home=True)

@app.route('/aboutus')
def about():
    return render_template('admin/aboutus.html', title="About us")

@app.route('/products')
def products():
   clothes_products = Product.query.filter_by(category='Clothes' ).all()
   food_products = Product.query.filter_by(category='Food' ).all()
   electronique_products = Product.query.filter_by(category='Electronic' ).all()
   accessoire_products = Product.query.filter_by(category='Accessories' ).all()
   
   try:
    if session['name']:
      
        ratings_list = Ratings.query.all()
        ratings = [(rating.user_id, rating.product_id, rating.rating) for rating in ratings_list]
        if ratings :
            user_id = User.query.filter_by(name = session['name']).first().id
            recommanded_product_id = colfil(user_id,ratings, 3)
            recommanded_products = []
            for id in recommanded_product_id:
                product = Product.query.filter_by(id = id).first()
                recommanded_products.append(product)
        else :
            recommanded_products = []
      
        return render_template('admin/product.html', title='E-CCN : Home page', recommanded_products=recommanded_products, clothes_products=clothes_products,  username=session['name'], food_products=food_products, electronique_products=electronique_products, accessoire_products=accessoire_products)
    return render_template('admin/product.html', title='E-CCN : Home page', clothes_products=clothes_products, food_products=food_products, electronique_products=electronique_products,username=session['name'], accessoire_products=accessoire_products)
   except KeyError:
    return render_template('admin/product.html', title='E-CCN : Home page', clothes_products=clothes_products, food_products=food_products, electronique_products=electronique_products, accessoire_products=accessoire_products)
   
@app.route('/rate', methods=['POST'])
def rate_product():
    rating_data = request.json
    # Extract user_id, product_id, and rating from the request data
    user_id = rating_data['user_id']
    product_id = rating_data['product_id']
    rating = rating_data['rating']
    
    # Perform database operations to store the rating
    # code to interact with the database 
    rate = Ratings(user_id=user_id, product_id=product_id, rating=rating)
    db.session.add(rate)
    db.session.commit()
    flash('Thanks for rating this product!')
    # Return a response to acknowledge the operation's success
    return redirect(url_for('dash'))

@app.route('/products/<id>')
def product(id):
    product = Product.query.filter_by(id=id).first()
    id = product.id
    name = product.name
    price = product.price
    rating_id = product.rating_id
    description = product.description
    category = product.category
    photo = product.photo
    owner = User.query.filter_by(id=product.user_id).first()
    try:  
     user = User.query.filter_by(name=session['name']).first()
    except:
       user = ""

    return render_template('admin/prod_info.html', id=id,name=name, price=price, rating_id=rating_id, description=description, category=category, photo=photo, user=user, owner=owner)

@app.route('/chat/<owner_id>/<product_id>', methods=['GET', 'POST'])
def chat(owner_id,product_id):
   message = request.form.get("message")
   sender_id = User.query.filter_by(name=session['name']).first().id
   if message :
        new_message = Message(content=message, sender_id=sender_id, receiver_id=owner_id, product_id=product_id)
        db.session.add(new_message)
        db.session.commit()
        return redirect(url_for('dash', message=message))
   else:
        return redirect(url_for('product', id=product_id))
   
@app.route('/show/<sender_product>')
def show(sender_product):
   # Retrieve the sender.id and product.id from sender_product
    sender_product = list(map(int, sender_product.split('-')))
    other_id, product_id = sender_product[0], sender_product[1]


    user = User.query.filter_by(name=session['name']).first()
    recieved_messages = Message.query.filter_by(receiver_id=user.id, sender_id=other_id, product_id=product_id).order_by(desc(Message.timestamp)).all()
    sended_messages = Message.query.filter_by(sender_id=user.id, receiver_id=other_id, product_id=product_id).order_by(desc(Message.timestamp)).all()
    messages = recieved_messages + sended_messages
    messages = sorted(messages, key=lambda m: m.timestamp)
 
    message_list = []
    for message in messages:
     message_dict = {
        'id': message.id,
        'content': message.content,
        'sender_id': message.sender_id,
        'receiver_id': message.receiver_id,
        'timestamp': message.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
        'sender_name': message.sender.name,
        'receiver_name': message.receiver.name,
        'product_photo': message.product.photo,
        'product_name' : message.product.name,
        'product_desc': message.product.description
     }
     message_list.append(message_dict)

    return jsonify(message_list)
    
    

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm(request.form)
    if request.method == 'POST' and form.validate():
        hash_password = bcrypt.generate_password_hash(form.password.data)
        user = User(name=form.name.data, password=hash_password, email=form.email.data)
        db.session.add(user)
        db.session.commit()
        flash(f'Welcome {form.name.data} Thanks for registering', 'success')
        return redirect(url_for('login'))
    return render_template('admin/register.html', form=form, title="Registration page" )


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm(request.form)
    if request.method == "POST" and form.validate():
        user = User.query.filter_by(email = form.email.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            session['email']= form.email.data
            user = User.query.filter_by(email=form.email.data).first()
            session['name']= user.name
            flash(f'Welcome {user.name} You are logged in !', 'success')
            
            return redirect(url_for('dash'))
        else:
            flash('Wrong password, please try again !', 'danger')
            
    return render_template('admin/login.html', form=form, title='Login page')



@app.route('/dashboard')
def dash():
    # chat variables 
    sender = request.args.get('sender', default= None)
    product = request.args.get('product', default= None)


    user = User.query.filter_by(name=session['name']).first()
    products = Product.query.filter_by(user_id=user.id).all()
    recieved_messages = Message.query.filter_by(receiver_id=user.id).order_by(desc(Message.timestamp)).all()
    sended_messages = Message.query.filter_by(sender_id=user.id).order_by(desc(Message.timestamp)).all()
    messages = recieved_messages + sended_messages
    messages = sorted(messages, key=lambda m: m.timestamp, reverse=True)
    if sender :
       return render_template('admin/dashboard.html',user=user, messages=messages,  sender=sender, product=product)
    else:
        return render_template('admin/dashboard.html', title='Dashboard page', user=user, products=products, messages=messages)

@app.route('/add-product', methods=['POST'])
def add_product():
    product_name = request.form.get("product_name")
    product_category = request.form.get("product_category")
    product_price = request.form.get("product_price")
    product_description = request.form.get("product_description")
    product_photo = request.files['product_photo']
    user = User.query.filter_by(name=session['name']).first()
    user_id = user.id

    if product_name is None or len(product_name) < 1:
        flash('Product name must be set', 'danger')
    elif product_description is None or len(product_description) < 1:
        flash('Please set a description for the product', 'danger')
    elif product_category is None or len(product_category) < 1:
        flash("Please set the product's category", 'danger')
    elif product_price is None or float(product_price) < 0:
        flash('Please set a valid price for the product', 'danger')
    elif not product_photo :
        flash(f'Please set a photo for the product', 'danger')
    else:
        # Save the uploaded file to the uploads folder
        filename = product_photo.filename
        upload_folder_path = os.path.join(app.root_path, app.config['UPLOAD_FOLDER']) 
        os.makedirs(upload_folder_path, exist_ok=True)
        file_path = os.path.join(upload_folder_path, filename)
        product_photo.save(file_path)

        # Process the form data and perform necessary actions
        new_product = Product(name=product_name, price=float(product_price), category=product_category, description=product_description, photo=filename, user_id=user_id)
        db.session.add(new_product)
        db.session.commit()
        flash("Product added successfully", "success")
        return redirect(url_for('dash'))
    return redirect(url_for('dash'))


@app.route('/delete-product/<int:product_id>', methods=['GET', 'POST'])
def delete_product(product_id):
    product = Product.query.get(product_id)  # Retrieve the product from the database
    if product:
        db.session.delete(product)  # Delete the product
        db.session.commit()  # Commit the changes to the database
        flash("Product deleted successfully", "success")
    else:
        flash("Product not found", "error")
    return redirect(url_for('dash'))

